# CLI Commands

*Command-line interface for mkvdup.*

[Back to Architecture Overview](../DESIGN.md)

## Global Options

```bash
# Enable verbose/debug output for any command
mkvdup -v <command> [args...]
mkvdup --verbose <command> [args...]

# Examples:
mkvdup -v create video.mkv /source/dir
mkvdup -v mount /mnt/media config1.yaml config2.yaml
mkvdup -v verify video.mkvdup /source/dir video.mkv
```

**Verbose mode enables:**
- FUSE operation logging (Open, Read, Lookup, Readdir)
- Detailed verification output with byte comparisons
- Debug information for troubleshooting

## Commands

### create

Create a dedup file from an MKV and its source directory.

```bash
mkvdup create [options] <mkv-file> <source-dir> [output] [name]

# Examples:
mkvdup create movie.mkv /media/dvd-backups
mkvdup create movie.mkv /media/dvd-backups movie.mkvdup
mkvdup create movie.mkv /media/dvd-backups movie.mkvdup "Movies/Action/movie.mkv"
mkvdup create --warn-threshold 50 movie.mkv /media/dvd-backups
mkvdup create --quiet movie.mkv /media/dvd-backups
mkvdup create --non-interactive movie.mkv /media/dvd-backups
```

**Arguments:**
- `<mkv-file>` — Path to the MKV file to deduplicate
- `<source-dir>` — Directory containing source media (ISO files or BDMV folders)
- `[output]` — Output `.mkvdup` file (default: `<mkv-file>.mkvdup`)
- `[name]` — Display name in FUSE mount (default: basename of mkv-file)

**Options:**

| Option | Description |
|--------|-------------|
| `--warn-threshold N` | Minimum space savings percentage to avoid warning (default: `75`) |
| `--quiet` | Suppress the space savings warning |
| `--non-interactive` | Don't prompt on codec mismatch (show warning and continue) |

**Codec check:** Before matching, codecs in the MKV are compared against the source media. If a mismatch is detected (e.g., MKV has H.264 but source is MPEG-2), you will be prompted to continue or abort. Use `--non-interactive` for scripted usage. When stdin is not a terminal, non-interactive mode is used automatically.

**Outputs:**
- `video.mkvdup` — The dedup data file (index + delta)
- `video.mkvdup.yaml` — Config file for this mapping

**Directory paths in `name`:**
The `name` argument supports directory paths (e.g., `"Movies/Action/Video1.mkv"`). Each `create` command produces one `.mkvdup` file with one name stored in its config. The directory structure becomes visible when mounting multiple configs together—directories are auto-created from path components across all mounted files. See [FUSE Directory Structure](FUSE.md#directory-structure) for details.

### batch-create

Create multiple dedup files from MKVs sharing the same source directory. The source is indexed once and reused for all files, which is significantly faster than running `create` separately for each file. Codec compatibility is checked for each file; if a mismatch is detected, a warning is printed but processing continues (always non-interactive).

```bash
mkvdup batch-create [options] <manifest.yaml>

# Examples:
mkvdup batch-create episodes.yaml
mkvdup batch-create --quiet episodes.yaml
mkvdup batch-create --warn-threshold 50 episodes.yaml
```

**Arguments:**
- `<manifest.yaml>` — YAML manifest specifying the shared source directory and MKV files

**Options:**

| Option | Description |
|--------|-------------|
| `--warn-threshold N` | Minimum space savings percentage to avoid warning (default: `75`) |
| `--quiet` | Suppress the space savings warning |

**Manifest format:**

```yaml
source_dir: /media/dvd-backups/disc1

files:
  - mkv: episode1.mkv
    output: episode1.mkvdup        # optional (default: <mkv>.mkvdup)
    name: "Show/S01/Episode 1.mkv" # optional (default: basename of mkv)

  - mkv: episode2.mkv

  - mkv: /absolute/path/to/episode3.mkv
    output: /absolute/path/to/episode3.mkvdup
```

**Manifest fields:**

| Field | Required | Description |
|-------|----------|-------------|
| `source_dir` | Yes | Shared source directory for all MKV files |
| `files` | Yes | List of MKV files to process (at least one) |
| `files[].mkv` | Yes | Path to the MKV file |
| `files[].output` | No | Output `.mkvdup` file (default: `<mkv>.mkvdup`) |
| `files[].name` | No | Display name in FUSE mount (default: basename of mkv) |

Relative paths are resolved against the manifest file's directory.

**Partial failure handling:**
- If one file fails, processing continues for the remaining files
- A summary at the end shows OK/FAIL status for each file
- Exit code is 1 if any file failed, 0 if all succeeded

### mount

Mount virtual filesystem from config files.

```bash
# Mount from config file(s)
mkvdup mount /mnt/videos config1.mkvdup.yaml config2.mkvdup.yaml

# Mount from a config with includes
mkvdup mount /mnt/videos /etc/mkvdup/mount.yaml

# Mount from config directory
mkvdup mount --config-dir /mnt/videos /etc/mkvdup.d/

# Mount with custom default permissions
mkvdup mount --default-uid 1000 --default-gid 1000 /mnt/videos config.yaml

# Mount with allow-other (for other users to access)
mkvdup mount --allow-other /mnt/videos config.yaml

# Run in foreground (for debugging or systemd)
mkvdup mount --foreground /mnt/videos config.yaml
```

Config files support `includes` (glob patterns referencing other configs, including
`**` recursive globs) and `virtual_files` (inline file definitions). See
[FUSE Configuration](FUSE.md#config-files-with-includes) for details.

**Options:**

| Option | Description |
|--------|-------------|
| `--allow-other` | Allow other users to access the mount (requires `/etc/fuse.conf` setting) |
| `--foreground`, `-f` | Run in foreground (don't daemonize) |
| `--config-dir` | Treat config argument as directory of YAML files (`.yaml`, `.yml`) |
| `--pid-file PATH` | Write daemon PID to file |
| `--daemon-timeout DUR` | Timeout waiting for daemon startup (default: `30s`) |

**Permission Options:**

| Option | Description |
|--------|-------------|
| `--default-uid UID` | Default UID for files and directories (default: calling user's UID) |
| `--default-gid GID` | Default GID for files and directories (default: calling user's GID) |
| `--default-file-mode MODE` | Default mode for files, in octal (default: `0444`) |
| `--default-dir-mode MODE` | Default mode for directories, in octal (default: `0555`) |
| `--permissions-file PATH` | Explicit path to permissions file |

**Permissions file search order:**
1. `--permissions-file PATH` (if specified)
2. `~/.config/mkvdup/permissions.yaml` (if exists)
3. `/etc/mkvdup/permissions.yaml` (if exists)

New permissions are written to:
- `~/.config/mkvdup/permissions.yaml` (for non-root users)
- `/etc/mkvdup/permissions.yaml` (when running as root, unless `~/.config/mkvdup/permissions.yaml` exists)

### verify

Verify an existing dedup file against the original MKV.

```bash
mkvdup verify <dedup-file> <source-dir> <original-mkv>

# Example:
mkvdup verify movie.mkvdup /media/dvd-backups original.mkv
```

### check

Check integrity of a dedup file and its source files without requiring the original MKV.

```bash
mkvdup check <dedup-file> <source-dir>
mkvdup check --source-checksums <dedup-file> <source-dir>
```

**Arguments:**
- `<dedup-file>` — Path to the .mkvdup file
- `<source-dir>` — Directory containing the source media

**Options:**

| Option | Description |
|--------|-------------|
| `--source-checksums` | Verify source file checksums (reads entire source files) |

**Checks performed:**
1. Dedup file integrity: index and delta internal checksums
2. Source file existence: all referenced source files must be present
3. Source file sizes: actual sizes must match expected sizes
4. Source file checksums (`--source-checksums` only): xxhash verification of source file contents

**Use case:** After archiving, verify that your dedup files and source media are intact without needing the original MKV files. This sits between `validate` (config-level checks) and `verify` (full byte-for-byte reconstruction requiring the original MKV).

**Examples:**

```bash
# Quick check (dedup integrity + source existence/sizes)
mkvdup check movie.mkvdup /media/dvd-backups

# Full check including source file checksums
mkvdup check --source-checksums movie.mkvdup /media/dvd-backups
```

### validate

Validate configuration files for correctness before mounting.

```bash
mkvdup validate [config.yaml...]
mkvdup validate --config-dir /etc/mkvdup.d/
mkvdup validate --deep config.yaml
mkvdup validate --strict config1.yaml config2.yaml
```

**Arguments:**
- `<config.yaml...>` — YAML config files to validate

**Options:**

| Option | Description |
|--------|-------------|
| `--config-dir` | Treat config argument as directory of YAML files (`.yaml`, `.yml`) |
| `--deep` | Verify dedup file headers and internal checksums |
| `--strict` | Treat warnings as errors (exit code 1 on warnings) |

**Validations performed:**
1. YAML syntax and required fields (`name`, `dedup_file`, `source_dir`)
2. Include resolution (glob patterns, cycle detection)
3. Path existence: dedup file exists, source directory exists and is a directory
4. Dedup file header: magic number, version, source file metadata
5. Name validation: rejects `..` components and empty names
6. Duplicate detection: warns on duplicate virtual file names across configs
7. Conflict detection: warns when a file name conflicts with a directory path
8. Deep checksums (`--deep` only): verifies index and delta integrity checksums

**Exit codes:**
- `0` — All valid (warnings are OK unless `--strict`)
- `1` — Errors found, or warnings with `--strict`

**Examples:**

```bash
# Validate a single config
mkvdup validate movie.mkvdup.yaml

# Validate all configs in a directory
mkvdup validate --config-dir /etc/mkvdup.d/

# Full integrity check
mkvdup validate --deep /etc/mkvdup.conf

# CI/pre-mount check (warnings = failure)
mkvdup validate --strict /etc/mkvdup.conf
```

### info

Show information about a dedup file.

```bash
mkvdup info <dedup-file>

# Example:
mkvdup info movie.mkvdup
```

### extract *(planned — [#13](https://github.com/stuckj/mkvdup/issues/13))*

Rebuild/extract original MKV from dedup + source. **Not yet implemented.**

```bash
# Planned syntax:
mkvdup extract <dedup-file> <source-dir> <output-mkv>
```

### probe

Quick test if an MKV likely matches a source. Useful for multi-disc sets.

```bash
mkvdup probe /path/to/video.mkv /path/to/source1 /path/to/source2 ...

# Example output:
#   Probing video.mkv against 3 sources...
#   Sampling 20 packets from MKV...
#
#   Results:
#     /data/disc1  18/20 matches (90%) ← likely match
#     /data/disc2   2/20 matches (10%)
#     /data/disc3   0/20 matches (0%)
```

**Use case:** You have 5 ISOs from a multi-disc set and 20 MKV files. Rather than trying each combination with full dedup (which takes minutes per attempt), probe can test all combinations in under a minute.

**Algorithm:**
1. Parse MKV file (quick scan, not full parse)
2. Sample 20 packets from different positions (5 from first 10%, 10 from middle 80%, 5 from last 10%)
3. For each source: look up each sampled packet hash, count matches
4. Report match percentages, sorted by likelihood

**Output interpretation:**
- 80-100% match: Very likely the correct source
- 40-80% match: Possible match (may be partial content or different encode settings)
- <40% match: Unlikely to be the source

### reload

Reload a running daemon's configuration by validating the config and sending SIGHUP.

```bash
mkvdup reload --pid-file /run/mkvdup.pid config.yaml
mkvdup reload --pid-file /run/mkvdup.pid --config-dir /etc/mkvdup.d/
mkvdup reload --pid-file /run/mkvdup.pid
```

**Required Options:**

| Option | Description |
|--------|-------------|
| `--pid-file PATH` | PID file of the running daemon (must match mount's `--pid-file`) |

**Options:**

| Option | Description |
|--------|-------------|
| `--config-dir` | Treat config argument as directory of YAML files (`.yaml`, `.yml`) |

If config files are provided, they are validated before sending the signal. If validation fails, the signal is not sent and errors are reported. If no config files are specified, the signal is sent without pre-validation (the daemon validates internally on SIGHUP).

The daemon re-reads its original config paths on SIGHUP, expanding include globs and `--config-dir` directories to pick up new files. See [Hot Reload](FUSE.md#hot-reload-via-sighup) for daemon-side behavior.

**systemd integration:**
```ini
[Service]
ExecStart=/usr/bin/mkvdup mount --foreground --pid-file /run/mkvdup.pid /mnt/videos /etc/mkvdup.conf
ExecReload=/usr/bin/mkvdup reload --pid-file /run/mkvdup.pid /etc/mkvdup.conf
```

### deltadiag

Analyze unmatched (delta) regions in a dedup file by cross-referencing with the original MKV to classify what stream type each delta region belongs to.

```bash
mkvdup deltadiag <dedup-file> <mkv-file>

# Example:
mkvdup deltadiag movie.mkvdup movie.mkv
```

**Arguments:**
- `<dedup-file>` -- Path to the .mkvdup file
- `<mkv-file>` -- Path to the original MKV file

**Output includes:**
- Total delta breakdown by stream type (video, audio, container)
- H.264 NAL type breakdown for video delta (SPS, PPS, SEI, slices, etc.)
- Slice NAL size distribution (small vs large)
- Summary with percentages of original file size

**Use case:** After creating a dedup file, use deltadiag to understand where the unmatched bytes are. This helps identify matching issues (e.g., audio streams that should be matching but aren't) and validate that improvements to the matching algorithm are working.

### Debug Commands

```bash
# Parse and display MKV structure
mkvdup parse-mkv /path/to/video.mkv

# Index a source directory
mkvdup index-source /path/to/source_dir

# Match packets (debugging)
mkvdup match video.mkv /path/to/source_dir
```

## Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | General error (invalid arguments, file not found, verification failed, etc.) |

## Warning Threshold

If space savings fall below the warning threshold (default: 75%), a warning is shown but the file is still created:

```
WARNING: Space savings (28.4%) below 75%
  This may indicate wrong source or transcoded MKV.
```

Use `--warn-threshold N` to customize the percentage, or `--quiet` to suppress the warning entirely. These options are available on both `create` and `batch-create`.

```bash
# Lower the threshold to 50%
mkvdup create --warn-threshold 50 movie.mkv /media/dvd-backups

# Suppress warnings entirely
mkvdup create --quiet movie.mkv /media/dvd-backups
```

## Statistics Output

The `create` command shows detailed statistics:

```
=== Results ===
MKV file size:      3,420,000,000 bytes (3261.19 MB)
Matched bytes:      3,418,000,000 bytes (3259.28 MB, 99.9%)
Delta (unmatched):  1,500,000 bytes (1.43 MB, 0.0%)

Dedup file size:    52,700,000 bytes (50.24 MB)
Space savings:      98.5%

Packets matched:    2,139,988 / 2,139,988 (100.0%)
Index entries:      2,139,988
```

## Related Documentation

- [FUSE Configuration](FUSE.md) - Mount configuration and daemon options
- [File Format](FILE_FORMAT.md) - Binary format of .mkvdup files
