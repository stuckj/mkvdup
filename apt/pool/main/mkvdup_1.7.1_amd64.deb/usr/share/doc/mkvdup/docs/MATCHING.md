# Matching Algorithms

*How MKV packets are matched to source media for deduplication.*

[Back to Architecture Overview](../DESIGN.md)

## Overview

The matching process involves five stages:
1. **Source Indexer** - Build a hash index of the source media
2. **MKV Parser** - Extract codec data locations from the MKV
3. **Matcher** - Find MKV packets in the source using hash lookups
4. **TrueHD Gap-Fill** - Fill unmatched TrueHD gaps using adjacent matched regions
5. **Verification** - Confirm byte-perfect reconstruction

## Source Indexer

### Source Type Detection

The source type is detected by scanning the directory structure:
- **DVD**: Contains `*.iso` file(s) with ISO 9660 filesystem
- **Blu-ray (directory)**: Contains `BDMV/STREAM/*.m2ts` files
- **Blu-ray (ISO)**: Contains `*.iso` file(s) with UDF filesystem

For ISO files, detection first attempts ISO 9660 (DVD). If the ISO does not contain a valid ISO 9660 primary volume descriptor, it falls back to UDF parsing for Blu-ray ISOs.

### Codec Detection

Different media use different video codecs:

| Media | Video Codecs | Container |
|-------|-------------|-----------|
| DVD | MPEG-2 | VOB (MPEG-PS) |
| Blu-ray | H.264/AVC, MPEG-2, VC-1, HEVC | M2TS (MPEG-TS) |

### Start Code Patterns

| Codec | Start Code Pattern | Notes |
|-------|-------------------|-------|
| MPEG-2 | `00 00 01 xx` | xx = B3 (seq), 00 (pic), 01-AF (slice) |
| H.264/AVC | `00 00 01 xx` or `00 00 00 01 xx` | xx = NAL unit type |
| HEVC | `00 00 01 xx` or `00 00 00 01 xx` | xx = NAL unit type |
| VC-1 | `00 00 01 xx` | Different structure |

Since most video codecs use `00 00 01` as a start code prefix, we scan for this pattern and index at each occurrence.

### Audio Sync Patterns

| Codec | Sync Pattern | Notes |
|-------|-------------|-------|
| AC3 (Dolby Digital) | `0B 77` | 2-byte sync word |
| DTS | `7F FE 80 01` | 4-byte sync word |
| TrueHD | `F8 72 6F BA` | 4-byte sync word |
| MPEG Audio (MP2/MP3) | `FF Fx` | 11-bit sync, x varies |
| LPCM/PCM | (none) | Raw samples, no framing (fixed-interval sync) |

## ES-Aware Indexing (DVD)

**Problem:** DVDs use MPEG Program Stream (MPEG-PS) containers which wrap Elementary Stream (ES) data in PES packets. When extracting to MKV, tools extract the raw ES data, stripping all container framing. If we index raw file offsets in the ISO, the container bytes create misalignments.

**Solution:** Parse the MPEG-PS structure and build an index based on **ES offsets** (continuous byte positions within the elementary stream) rather than raw file offsets.

```
MPEG-PS file structure:
┌─────────────┬──────────────────────┬─────────────┬──────────────────────┬───
│ Pack Header │ PES Packet (video)   │ Pack Header │ PES Packet (video)   │...
│  (14 bytes) │ [header][payload]    │  (14 bytes) │ [header][payload]    │
└─────────────┴──────────────────────┴─────────────┴──────────────────────┴───
                      │                                     │
                      ▼                                     ▼
Extracted video ES:   [payload bytes...............][payload bytes...........]
ES offset:            0                             1234
File offset:          47                            1314
```

The parser maintains a mapping of ES offsets to file offsets for each PES payload range.

## ES-Aware Indexing (Blu-ray)

**Problem:** Blu-rays use MPEG Transport Stream (MPEG-TS) containers in M2TS files. M2TS files consist of fixed-size 192-byte packets: a 4-byte timecode prefix plus a 188-byte TS packet (which itself has a 4-byte header, leaving up to 184 bytes for payload). Each TS packet carries a small fragment of a PES packet, identified by a 13-bit PID. PES packets span multiple TS packets and contain the actual codec data. When extracting to MKV, tools extract the raw ES data, stripping all TS and PES framing. If we index raw file offsets in the M2TS file, the 8-byte headers (4-byte timecode + 4-byte TS header, interleaved every 192 bytes) cause misalignments — expansion fails at every packet boundary.

**Solution:** Parse the MPEG-TS structure (PAT → PMT → PES packets) and build an index based on continuous ES offsets, the same approach used for DVDs.

```
M2TS file structure (192-byte packets):
┌───────────┬──────────────────────────────────────────────────────────────┐
│ Timecode  │ TS Packet (188 bytes)                                        │
│ (4 bytes) │ [sync 0x47][PID][flags][adaptation?][PES payload ≤184 bytes] │
└───────────┴──────────────────────────────────────────────────────────────┘
             └─ 4-byte TS header ─┘

PES packets span multiple TS packets:
┌──────────────────────┐  ┌──────────────────────┐  ┌──────────────────────┐
│ TS pkt (PUSI=1)      │  │ TS pkt (continuation)│  │ TS pkt (continuation)│
│ [PES header][payload]│  │ [payload............]│  │ [payload............]│
└──────────────────────┘  └──────────────────────┘  └──────────────────────┘
         │                         │                         │
         ▼                         ▼                         ▼
ES:      [payload bytes....][payload bytes.........][payload bytes.........]
ES off:  0                  ~167                    ~351
```

### Key Differences from DVD (MPEG-PS)

| Feature | DVD (MPEG-PS) | Blu-ray (MPEG-TS) |
|---------|--------------|-------------------|
| Container | MPEG Program Stream | MPEG Transport Stream |
| Packet size | Variable | Fixed 192 bytes (M2TS) or 188 bytes (TS) |
| Stream ID | Stream ID byte in PES header | PID (13-bit) per TS packet |
| Audio framing | Private Stream 1 with 4-byte sub-headers | Separate PID per audio track, no sub-headers |
| Audio sub-streams | Sub-stream IDs (0x80-0x87 = AC3, etc.) | PIDs mapped to sequential byte IDs (0, 1, 2...) for audio and subtitle |
| user_data filtering | Required (MPEG-2 video) | Not needed for H.264/H.265 (only for MPEG-2) |

### PAT/PMT Parsing

The parser identifies streams via MPEG-TS Program Specific Information:
1. **PAT** (PID 0): Maps program numbers to PMT PIDs
2. **PMT**: Lists elementary stream PIDs and their stream types (e.g., 0x1B = H.264, 0x81 = AC3)

### Audio PID Mapping

Unlike DVDs where audio is multiplexed in Private Stream 1 with sub-stream IDs, Blu-ray audio tracks have individual PIDs. The parser assigns sequential byte sub-stream IDs (0, 1, 2, ...) to audio and subtitle PIDs in PMT order, maintaining compatibility with the `Location.AudioSubStreamID` field used throughout the codebase. PGS subtitle PIDs (stream type 0x90) are included in the same sub-stream infrastructure as audio.

## Blu-ray TrueHD+AC3 Stream Splitting

**Problem:** On Blu-ray discs, TrueHD audio streams (PMT stream type 0x83) embed an AC3 compatibility core interleaved in the same PID. The raw PES payload data looks like:

```
PES payload: [AC3 frame][TrueHD AU(s)][AC3 frame][TrueHD AU(s)]...
```

Video extraction tools split these into separate MKV tracks: one for TrueHD-only data, one for the AC3 core. If we index them as a single combined sub-stream, the interleaved AC3+TrueHD bytes don't match either MKV track.

**Solution:** After parsing all PES payloads, detect combined TrueHD+AC3 streams by scanning the first 16KB of ES data for both AC3 sync words (`0B 77`) and TrueHD major sync words (`F8 72 6F BA`). When both are found, split the ranges using **AU-aware boundary parsing**:

The interleaved stream alternates between AC3 frames and TrueHD access units at unit boundaries. At each boundary, the parser determines the unit type and size:

1. **AC3 frame detection**: At a unit boundary, check for AC3 sync word (`0B 77`). If found, read byte 4 for `fscod` (2-bit sample rate code) and `frmsizecod` (6-bit frame size code). The frame size is deterministic from these values (ATSC A/52 Table 5.18).
2. **TrueHD AU detection**: If not AC3, parse the TrueHD access unit length from the first 2 bytes. The lower 12 bits encode the length in 16-bit words (multiply by 2 for bytes). TrueHD AUs are typically 38-58 bytes for minor sync frames, larger for major sync frames.
3. **State machine**: The parser tracks `ac3Remaining` and `truehdRemaining` counters to consume the current unit's bytes before checking the next boundary. This prevents false-positive AC3 detection inside TrueHD AU data (which may coincidentally contain `0B 77`).
4. **Cross-boundary buffering**: When a unit boundary falls across a PES payload range boundary, up to 5 bytes are buffered (2 for type detection, 5 for full AC3 header) and resolved when the next range begins.
5. **Range merging**: After splitting, merge adjacent ranges that are contiguous in both file offset and ES offset to reduce range count.

The original sub-stream ID keeps the TrueHD-only ranges; a new sub-stream ID is assigned for the AC3 core.

**Impact:** On a 41GB Blu-ray, TrueHD delta dropped from ~1,685 MB to 12 MB after AU-aware splitting combined with gap-fill matching (see below). The clean separation also improves AC3 matching since the AC3 ES is no longer contaminated with misclassified TrueHD data.

## TrueHD Gap-Fill Matching

**Problem:** Hash-based matching for TrueHD audio relies on finding major sync frames (`F8 72 6F BA`) as sync points. However, TrueHD major syncs occur only every ~8 access units. Packets that don't contain a major sync have no sync point, so hash-based matching and expansion cannot reach them. This leaves ~46% of TrueHD data unmatched despite being byte-identical to the source.

**Solution:** After parallel hash-based matching completes, a sequential gap-fill post-pass walks TrueHD packets between existing matched regions (anchors) and verifies bytes against the source ES:

1. **Anchor identification**: For each TrueHD track, collect existing matched regions and sort by MKV offset. Each region provides a known mapping from MKV offset to source ES offset.
2. **Gap enumeration**: For each pair of adjacent matched regions, compute the MKV gap (unmatched packets between them) and the corresponding source ES gap.
3. **Segment collection**: Within each MKV gap, collect the TrueHD packet byte ranges (skipping interleaved video/audio data from other tracks).
4. **Greedy forward comparison**: Read the expected source ES data and compare byte-by-byte against the MKV segments. On match, extend the current run. On mismatch, flush any pending run (if ≥16 bytes) and advance the MKV position by one byte (skipping extra bytes not present in the source ES).
5. **Region recording**: Matching runs of ≥16 bytes are recorded as new matched regions, which are merged with existing regions during the normal merge pass.

The MKV may contain small "extra" bytes not present in the source ES, caused by differences in how video extraction tools and the source parser split AC3 frames from the interleaved TrueHD+AC3 stream. The greedy skip-on-mismatch approach handles these transparently.

**Impact:** On a 41GB Blu-ray, TrueHD tracks went from ~54% matched to effectively 100% matched. Combined with AU-aware AC3 splitting, TrueHD delta dropped from ~1,685 MB to 12 MB (expected framing differences). Overall space savings improved from 93.8% to 98.9%.

## Blu-ray DTS-HD + DTS Core Stream Splitting

**Problem:** On Blu-ray discs, DTS-HD audio streams (PMT stream types 0x85/0x86) embed a DTS core within each audio frame, followed by extension data (ExSS: XBR, XLL, XXCh). The PES payload contains:

```
PES payload: [DTS core frame][ExSS extension][DTS core frame][ExSS extension]...
```

Video extraction tools may extract either the full DTS-HD stream (as `A_DTS/LOSSLESS` or `A_DTS/EXPRESS`) or just the DTS core (as `A_DTS`). If we only index the combined stream, the `A_DTS` MKV track can't match because its ES offsets skip the extension data that's present in the source.

**Solution:** After parsing PES payloads, detect combined DTS-HD streams by scanning for both DTS core sync words (`7F FE 80 01`) and DTS-HD ExSS sync words (`64 58 20 25`). When both are found, extract the DTS core frames into a new sub-stream:

1. **Actual core size detection**: The FSIZE field in DTS core headers reports the full access unit size (core + extension), not the core-only size. To find the real core boundary, `detectActualDTSCoreSize` reads the first 32KB of ES data and scans forward from the first DTS sync word for either an ExSS sync (`64 58 20 25`) or the next DTS core sync (`7F FE 80 01`). The distance from the DTS sync to this boundary is the actual core frame size. This handles both DTS-HD MA streams (where FSIZE is inflated) and older MKVs where the extraction tool already produced core-only data (where FSIZE matches the real core size).
2. **DTS core frame detection**: When `7F FE 80 01` is found, the header's FSIZE field is validated (must parse to a value in range 96-16384), but the detected actual core size from step 1 is used for frame boundaries instead of FSIZE.
3. **Range extraction**: DTS core frame bytes are collected into a new core-only sub-stream. All other bytes (ExSS extension data) remain in the original combined stream.
4. **Cross-range tracking**: DTS core frames may span TS payload chunks. The `coreRemaining` counter tracks bytes still belonging to the current core frame across range boundaries.
5. **Range merging**: After extraction, merge adjacent ranges that are contiguous in both file offset and ES offset.

Unlike TrueHD+AC3 splitting (which replaces the original stream), DTS-HD splitting **preserves the original combined sub-stream** and adds a new core-only sub-stream. This supports both MKV variants:
- `A_DTS` tracks match against the extracted core sub-stream
- `A_DTS/LOSSLESS` tracks match against the original combined sub-stream

### DTS-HD FSIZE Header Field

The DTS core header contains a 14-bit FSIZE field (bits 14-27 after the sync word) that, per ETSI TS 102 114, reports "Frame Byte Size" as the number of bytes in the frame (parsed value + 1). In standalone DTS core streams, FSIZE accurately reflects the core frame size. However, in DTS-HD streams (MA and HRA), FSIZE reports the **full access unit size** — the combined core frame plus extension data (ExSS). For example, a DTS-HD MA stream might report FSIZE=7743 when the actual core frame is only 2012 bytes.

Older versions of some video extraction tools extracted only the DTS core sub-stream from DTS-HD sources but preserved the original inflated FSIZE in the headers. Using FSIZE directly for core frame boundaries would include extension data bytes in the "core" ranges, causing ~35% of audio data to go unmatched (typical savings dropped from ~97% to ~90%).

The `detectActualDTSCoreSize` function handles both cases correctly by measuring the actual distance to the next sync boundary rather than trusting FSIZE.

## Blu-ray PGS Subtitle Matching

PGS (Presentation Graphic Stream) subtitles are carried in MPEG-TS with stream type 0x90. Video extraction tools extract these as MKV tracks with codec ID `S_HDMV/PGS`. On a typical Blu-ray, PGS data is 10-50 MB.

PGS subtitle streams are handled using the same sub-stream infrastructure as audio:

1. **PMT parsing**: PGS PIDs are assigned sequential sub-stream IDs alongside audio PIDs. They share the same `audioBySubStream` ranges, `ReadAudioSubStreamData()`, and range map encoding.
2. **Sync point detection**: PGS data uses a segment-based structure with 3-byte headers: `[type (1 byte)] [size (2 bytes BE)]`. Valid segment types are PDS (0x14), ODS (0x15), PCS (0x16), WDS (0x17), and END (0x80). Each segment start is a sync point, similar to how AVCC uses NAL unit boundaries.
3. **Indexing and matching**: The indexer uses `FindPGSSyncPoints` for subtitle sub-streams instead of `FindAudioSyncPoints`. The matcher dispatches `TrackTypeSubtitle` MKV packets to `FindPGSSyncPoints`.

No changes to the dedup file format, entry structure, or reader are needed — subtitle entries appear as non-video entries with their own sub-stream IDs, and the existing range map and reader infrastructure handles them transparently.

## Video user_data Filtering

**Problem:** MKV remuxing tools typically strip `user_data` sections (start code `00 00 01 B2`) from video streams. These contain closed captions and other auxiliary data.

**Solution:** When building the video ES index, create "filtered ranges" that exclude user_data sections:

```
Raw video ES:          [video][user_data][video][user_data][video]
Filtered video ES:     [video]...........[video]...........[video]
                       (user_data sections excluded)
```

**Result:** Video matching improved from ~60% to ~98.6% after user_data filtering.

## DVD Audio: Private Stream 1

DVD audio is carried in MPEG-PS Private Stream 1 (stream ID 0xBD). Each PES packet contains a 4-byte header before the audio data:

```
┌────────────┬─────────────┬──────────────────┬─────────────────────────────┐
│ Sub-stream │ Frame count │ First access ptr │ Audio data (AC3/DTS/LPCM)   │
│   ID (1)   │    (1)      │      (2)         │                             │
└────────────┴─────────────┴──────────────────┴─────────────────────────────┘

Sub-stream IDs:
  0x80-0x87: AC3 (Dolby Digital)
  0x88-0x8F: DTS
  0xA0-0xA7: LPCM
  0x20-0x3F: Subpictures
```

MKV tools strip this 4-byte header. We must do the same when building filtered audio ranges.

## Per-Sub-Stream Audio Filtering

**Problem:** Private Stream 1 carries multiple audio tracks interleaved:

```
PES packets in file order:
[0x80 audio][0x81 audio][0x80 audio][0x82 audio][0x80 audio][0x81 audio]...
```

When matching an MKV audio track (which contains only ONE language), we'd hit data from other tracks and matching would fail.

**Solution:** Create separate filtered ES ranges for each sub-stream ID. When matching MKV audio, match against only the specific sub-stream.

**Result:** Audio matching improved from ~25% to ~99%+ after per-sub-stream filtering.

## Index Data Structure

The source index contains:
- **Hash table**: Maps 64-bit xxhash → list of (file index, offset) locations
- **Source directory**: Path to the source media
- **Source type**: DVD or Blu-ray
- **File list**: Relative path, size, and checksum for each source file
- **Window size**: Number of bytes used for hashing (default: 64 bytes)

## MKV Parser

Parse the MKV file to identify codec data packet boundaries.

### MKV Structure (Matroska/WebM)

```
EBML Header
Segment
├── SeekHead (index)
├── Info (metadata)
├── Tracks (codec definitions)
├── Chapters
├── Clusters
│   ├── Timestamp
│   ├── SimpleBlock (video/audio packet)
│   ├── BlockGroup
│   │   ├── Block
│   │   └── BlockDuration
│   └── ...
└── Cues (seek index)
```

The actual codec data is inside `SimpleBlock` and `Block` elements. Each block contains:
- Track number (1 byte, variable)
- Timestamp offset (2 bytes)
- Flags (1 byte for SimpleBlock)
- Frame data (the codec bytes we want to match)

**Output:** List of (mkv_offset, length, hash) for each frame.

## Matcher Algorithm

```
For each MKV packet (mkv_offset, length, hash):
    1. Look up hash in SourceIndex.HashToLocations
    2. If found:
       a. For each candidate location:
          - Verify full match (compare all `length` bytes)
          - If match:
            - EXPAND match boundaries
            - Record expanded region as SOURCE reference
            - Mark MKV range as matched
            - Break on first match
    3. If not found or no verified match:
       - Mark as DELTA (unique data)
       - Append data to delta buffer
```

### Index Coverage

The index covers the ENTIRE MKV file:

```
MKV byte range 0-1000:        EBML header → DELTA
MKV byte range 1000-1050:     Cluster header → DELTA
MKV byte range 1050-9000:     Video frame → SOURCE file=0, offset=463000
MKV byte range 9000-9020:     Block header → DELTA
MKV byte range 9020-11000:    Audio packet → SOURCE file=0, offset=464500
```

## Boundary Expansion

After finding a match via hash lookup, expand in both directions to maximize deduplication. For both DVD and Blu-ray sources with ES-aware indexing, expansion reads continuous ES bytes through the ES reader interface, transparently skipping container framing (MPEG-PS pack headers or MPEG-TS packet headers).

```
Source (VOB/M2TS): [container][video data...............][container]
                              ^
                         start code (indexed)

MKV:               [ebml hdr][video data...............][block hdr]
                              ^
                         matches here

Without expansion: Only match from start code to next start code
With expansion:    Match extends to include adjacent matching bytes
```

**Algorithm:**
1. **Expand backward**: Compare bytes before match until mismatch
2. **Expand forward**: Compare bytes after match until mismatch
3. **Return**: Updated start offsets and expanded length

**Constraints:**
- Don't expand into already-matched regions
- Limit expansion distance (e.g., max 64KB each direction)

**Benefits:**
- Maximizes deduplication ratio
- Reduces delta size
- Captures partial matches at packet boundaries
- Helps with LPCM audio (no sync patterns)

## Verification

**Mandatory verification after deduplication.**

1. Create dedup file
2. Mount via FUSE (temporary, internal mount)
3. Open virtual MKV through FUSE
4. Open original MKV
5. Compare byte-by-byte (or in large chunks with hash comparison)
6. If mismatch: report error with offset, delete dedup file, exit with failure
7. If match: report success, optionally delete original (with --delete-original)

## Performance Results

*Results from Big Buck Bunny test data (see [testdata/README.md](../testdata/README.md) and #27).*

With all filtering implemented (ES-aware, user_data, per-sub-stream audio):

| Metric | Before Filtering | After Filtering |
|--------|-----------------|-----------------|
| Video byte match rate | ~60% | ~98.6% |
| Audio byte match rate | ~25% | ~99%+ |
| Overall byte match rate | ~50% | **98.4%** |
| Delta size (3.4GB MKV) | ~1.7GB | ~56MB |
| Storage savings | ~50% | **97.8%** |

The remaining ~1.6% unmatched data consists of:
- MKV container headers (EBML, cluster headers, block headers)
- Minor stream differences

## DVD LPCM Audio Matching

**Problem:** DVD LPCM audio (sub-stream IDs `0xA0`-`0xA7`) stores 16-bit samples as big-endian with per-frame headers, while MKV stores `A_PCM/INT/LIT` (raw little-endian PCM, no framing). The byte data is completely different despite containing identical audio. Without handling this, LPCM audio gets 0% match and falls entirely to delta, which can lose hundreds of MB on a typical LPCM-heavy DVD.

**Solution:** Transform LPCM ES data at the source parser layer, invisible to the indexing and matching code:

1. **Header stripping:** LPCM packets in Private Stream 1 have a 3-byte frame header after the 4-byte PS header (emphasis, mute, frame number, quantization, sample rate, channels, dynamic range control). We strip all 7 bytes, keeping only raw sample data — matching how video extraction tools produce MKV audio.

2. **16-bit byte swap:** For 16-bit LPCM (quantization code 0), apply an in-place byte swap to convert big-endian sample pairs `[HI][LO]` to little-endian `[LO][HI]`. This is done transparently in `ReadAudioSubStreamData()` and `ReadAudioByteWithHint()`, so the indexer and matcher see MKV-compatible data.

3. **Asymmetric sync points:** Since PCM has no natural sync patterns (no frame headers or sync words), we use fixed-interval sync points. The source indexer uses `FindLPCMIndexSyncPoints` with a 2048-byte interval (one sync point per PES payload range), while the MKV matcher uses `FindLPCMMatchSyncPoints` with an 8-byte interval. The dense MKV-side interval is necessary because DVD LPCM PES payloads (~2008 bytes) and MKV packets (~6400 bytes) have gcd(2008, 6400) = 8, so only an 8-byte interval guarantees alignment. The dense MKV interval adds no memory (sync points are used for hash lookups, not stored in the index).

4. **FUSE reconstruction:** The dedup entry's `IsLPCM` flag (ESFlags bit 1) tells the FUSE reader to apply the inverse byte swap when reading from the source. Since the 16-bit swap is its own inverse, this is a simple in-place operation with no memory allocation.

### 20-bit and 24-bit LPCM

DVD LPCM also supports 20-bit and 24-bit sample depths, which use a grouped big-endian packing format (upper 16-bit parts followed by packed lower bits). The MKV representation is interleaved little-endian 24-bit samples. For 20-bit, the transform changes data size (the grouped format is more compact than the interleaved output), which creates a coordinate system mismatch between source ES offsets and MKV offsets. This makes both indexing and in-place FUSE reconstruction infeasible without significant complexity.

Since 20-bit and 24-bit DVD LPCM is extremely rare in practice, these formats are not handled — their audio data falls through to delta storage.

## Locality-Based NAL Recovery

When hash-based matching fails for a video NAL (the hash is not found in the source index), the matcher attempts to recover it using the per-track locality hint. This handles NALs that the source indexer missed during indexing — the bytes exist in the source but were never hashed into the index.

### How It Works

1. Use the per-track locality hint (`lastSrcEnd` + `lastMkvEnd`) to predict where the current NAL should be in the source elementary stream
2. Probe a small window of offsets around the predicted location (±3 bytes to account for AVCC vs Annex B framing differences)
3. At each candidate offset, compare the first 4 bytes against the MKV NAL data to confirm alignment
4. If aligned, read the full NAL from the source and verify every byte matches

This works because consecutive NALs on the same track are packed sequentially in both MKV and source. After a successful match (hash-based or locality-based), the hint tracks where the match ended, providing an accurate prediction for the next NAL's source position.

### Why NALs Get Missed by the Indexer

The source indexer scans M2TS elementary streams for NAL start codes and hashes 64-byte windows at each sync point. In some cases, NALs can be missed:

- NALs at PES packet boundaries where the parser doesn't detect the start code
- NALs in M2TS segments with unusual packet interleaving
- Edge cases in the ES range extraction for multi-PID streams

The locality recovery catches these cases by using spatial prediction rather than relying on the hash index.

### Scope

Locality recovery applies to all video codecs on ES-based sources (Blu-ray):
- **H.264/H.265**: AVCC/HVCC length-prefixed NALs
- **VC-1**: Annex B start-code-separated frames
- **MPEG-2**: Annex B start-code-separated NALs

The NAL must be at least 64 bytes (the hash window size) and must have an exact size from a known next sync point.

### Remaining Unmatched NALs

After locality recovery, the remaining unmatched video NALs are:
- **Small metadata NALs** (<64 bytes): AUD, SEI, SPS, PPS — these are inherently unmatchable as extraction tools modify their contents during remux
- **Failed predictions**: NALs where the locality hint was stale (e.g., after a scene change or the first NAL on a track)

### Diagnostic Output

The `--verbose` flag reports locality recovery statistics:

```
Locality recovery:
  Attempts:  557710
  Matched:   5518
  Bytes:     166617544
```

## Related Documentation

- [File Format](FILE_FORMAT.md) - How matched entries are stored
- [CLI Commands](CLI.md) - Running the matching process
